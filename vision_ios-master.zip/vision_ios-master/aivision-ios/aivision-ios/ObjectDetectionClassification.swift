//
//  ImageClassification.swift
//  aivision-ios
//
//  Created by Chris Parsons on 13/08/2018.
//  Copyright © 2018 Chris Parsons. All rights reserved.
//

import Foundation

struct ObjectDetectionClassification {
    let classification: String
    let confidence: String
    let xmax: Int
    let xmin: Int
    let ymax: Int
    let ymin: Int
}
